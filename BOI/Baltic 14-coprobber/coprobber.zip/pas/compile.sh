#!/bin/sh

fpc -XS -O2 -vw grader.pas -ocoprobber
