#!/bin/sh

g++ coprobber.cxx grader.cxx -Wall -O2 -static -std=c++11 -o coprobber

