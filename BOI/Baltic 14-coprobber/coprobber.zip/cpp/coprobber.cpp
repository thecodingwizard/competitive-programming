#include "coprobber.h"

int start(int N, bool A[MAX_N][MAX_N])
{
    return 0;
}

int nextMove(int R)
{
    return 0;
}
