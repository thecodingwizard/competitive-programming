#!/bin/sh

xterm -e bash -c "./coprobber; read -p 'Press ENTER to exit...'"

