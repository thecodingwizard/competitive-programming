#!/bin/sh

g++ coprobber.cpp grader.cpp -O2 -static -Wall -o coprobber

