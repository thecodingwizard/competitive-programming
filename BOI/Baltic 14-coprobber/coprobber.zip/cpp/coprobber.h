#ifndef COPROBBER_H
#define COPROBBER_H

const int MAX_N = 500;

int start(int N, bool A[MAX_N][MAX_N]);
int nextMove(int R);

#endif  // COPROBBER_H
